package work_or.assignment.src.mianAPP;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;


public class MainGame extends Application {
    public static Stage staticScreen;

    private int weight;

    private int height;

    private int shipNumber;
    private Stage start_stage;

    public  Stage main_stage;

    public static VBox vBox_play = new VBox();

    public static VBox vBox_enemy = new VBox();

    private static Game game;

    @Override
    public void start(Stage primaryStage) throws Exception {

        show_begin_screen();

        BorderPane borderPane = new BorderPane();
        staticScreen = primaryStage;
        Scene scene = new Scene(borderPane,300,200);
        primaryStage.setScene(scene);
        scene.setFill(Color.rgb(245,222,179));
        primaryStage.setResizable(false);

    }

    private void show_begin_screen(){

        Label label_title = new Label("Welcome to my BattleShip Game");
        label_title.setPrefHeight(15);
        label_title.setLayoutX(20);
        label_title.setLayoutY(2);

        TextField textField_weight = new TextField();
        textField_weight.setPromptText("please enter a weight");
        textField_weight.setPrefWidth(150);
        textField_weight.setPrefHeight(20);
        textField_weight.setLayoutX(20);
        textField_weight.setLayoutY(30);

        TextField textField_height = new TextField();
        textField_height.setPromptText("please enter a height");
        textField_height.setPrefWidth(150);
        textField_height.setPrefHeight(20);
        textField_height.setLayoutX(20);
        textField_height.setLayoutY(70);

        TextField textField_shipNumber = new TextField();
        textField_shipNumber.setPromptText("ship number");
        textField_shipNumber.setPrefWidth(100);
        textField_shipNumber.setPrefHeight(20);
        textField_shipNumber.setLayoutX(190);
        textField_shipNumber.setLayoutY(30);

        Label ship_error = new Label();
        ship_error.setPrefHeight(15);
        ship_error.setLayoutY(65);
        ship_error.setLayoutX(185);
        ship_error.setTextFill(Color.RED);

        Label label_error = new Label();
        label_error.setPrefHeight(15);
        label_error.setLayoutY(95);
        label_error.setLayoutX(20);
        label_error.setTextFill(Color.RED);

        Button button_ok = new Button("submit");
        button_ok.setPrefWidth(80);
        button_ok.setPrefHeight(30);
        button_ok.setLayoutX(110);
        button_ok.setLayoutY(120);
        button_ok.setBackground(new Background(new BackgroundFill(Color.rgb(255, 185, 15),null,null)));

        textField_weight.setOnMouseClicked(mouseEvent ->{
            label_error.setText("");
            ship_error.setText("");
        });
        textField_height.setOnMouseClicked(mouseEvent ->{
            label_error.setText("");
            ship_error.setText("");
        } );
        textField_shipNumber.setOnMouseClicked(mouseEvent ->{
            label_error.setText("");
            ship_error.setText("");
        } );

        button_ok.setOnMouseClicked(mouseEvent -> {
            try {
                //获取文本框数据 去除两侧的空格
                weight = Integer.parseInt(textField_weight.getText().trim());
                height = Integer.parseInt(textField_height.getText().trim());
                shipNumber = Integer.parseInt(textField_shipNumber.getText().trim());
                if (weight>=3 && weight<=10 && height>=3 && height<=10 && shipNumber > 0){
                    start_stage.close();
                    show_main_screen();
                }else{
                    ship_error.setText("number should > 0");
                    label_error.setText("Please enter the integer between 3 to 10");
                }

            }catch (Exception e){
                ship_error.setText("number should > 0");
                label_error.setText("Please enter the integer between 3 to 10");
            }

                });

        Group group = new Group();
        group.getChildren().addAll(label_title,textField_weight,textField_height,textField_shipNumber,label_error,ship_error,button_ok);

        start_stage = new Stage();
        start_stage.getIcons().add(new Image("work_or/assignment/src/image/logo.jpg"));
        start_stage.setTitle("by 20213802045");

        Scene scene = new Scene(group,300,200);
        start_stage.setScene(scene);
        start_stage.show();

    }


    private void show_main_screen() {

        Label place = new Label("20213802045---2022/10/16");
        place.setPrefHeight(35);

        game = new Game(weight,height,shipNumber);

        BorderPane borderPane = new BorderPane();
        borderPane.setTop(getEnemy());  // 应该是敌军地图
        borderPane.setCenter(place);
        borderPane.setBottom(getPlayer());  // 我方地图

        main_stage = new Stage();
        main_stage.getIcons().add(new Image("work_or/assignment/src/image/logo.jpg"));
        main_stage.setTitle("by 20213802045");
        Scene scene = new Scene(borderPane);


        main_stage.setScene(scene);
        main_stage.show();


//
//
//        int round = 0;
//        while (true){
//            round++;
//            if (round % 2 != 0){
//                while (true){
//                    Scanner scanner = new Scanner(System.in);
//                    System.out.println("这是你的回合,请输入一个坐标 或其他操作");
//                    String sentence = scanner.next();
//                    if (!Objects.equals(sentence, "exit")) {
//                        try {
//                            game.playRound(sentence);
//                            break;
//                        }catch (Exception e){
//                            System.out.println("error, try again");
//                        }
//                    }else {
//                        game.exitGame(sentence);
//                    }
//                }
//            }else {
//                System.out.println("对方回合");
//                game.RobotRound();
//            }
//
//            if (game.checkVictory()){
//                break;
//            }
//
//        }


    }

    private BorderPane getPlayer(){
        int x = -1;
        int y ;
        for (String[] i : game.play.gameGrid) {
            x += 1;
            y = -1;
            HBox hBox = new HBox();
            for (String j:i) {
                y += 1;
                Apiece_play apiece = new Apiece_play(j,x,y);
                hBox.getChildren().add(apiece.label);
            }
            vBox_play.getChildren().add(hBox);
        }
        BorderPane buttonPane = new BorderPane();
        buttonPane.setCenter(vBox_play);
        return buttonPane;
    }

    public static void refresh_play(){
        int x = -1;
        int y ;
        for (String[] i : game.play.gameGrid) {
            x += 1;
            y = -1;
            HBox hBox = new HBox();
            for (String j:i) {
                y += 1;
                Apiece_play apiece = new Apiece_play(j,x,y);
                hBox.getChildren().add(apiece.label);
            }
            vBox_play.getChildren().add(hBox);
        }
    }



    private BorderPane getEnemy(){
        int x = -1;
        int y ;
        for (String[] i : game.enemy.gameGrid) {
            x += 1;
            y = -1;
            HBox hBox = new HBox();
            for (String j:i) {
                y += 1;
                Apiece_enemy apiece = new Apiece_enemy(j,x,y);
                hBox.getChildren().add(apiece.label);
            }
            vBox_enemy.getChildren().add(hBox);
        }
        BorderPane topPane = new BorderPane();
        topPane.setCenter(vBox_enemy);
        return topPane;
    }

    public static void refresh_enemy(){
        int x = -1;
        int y ;
        for (String[] i : game.enemy.gameGrid) {
            x += 1;
            y = -1;
            HBox hBox = new HBox();
            for (String j:i) {
                y += 1;
                Apiece_enemy apiece = new Apiece_enemy(j,x,y);
                hBox.getChildren().add(apiece.label);
            }
            vBox_enemy.getChildren().add(hBox);
        }
    }


    public static void checkVictory(){
        game.checkVictory();
    }


    public static void play_round(String input){
        game.playRound(input);
    }

    public static void enemy_round(){
        game.RobotRound();
        vBox_play.getChildren().clear();
        refresh_play();
        checkVictory();
    }


    public static void play(){
        launch();
    }

}
