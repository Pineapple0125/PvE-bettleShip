package work_or.assignment.src.mianAPP;



public abstract class AbstractBattleShip {
    
	protected String name;
	
	protected int hits; 
	
	protected String shipOrientation;  // 船的朝向
	
	protected int[][] shipCoordinates ; // 船的坐标
	
	
	public abstract boolean checkAttack (int row,int column);
	
	public abstract String getName();

	public abstract int getHits() ;
	
	public abstract String getShipOrientation() ;
	
	public abstract void setHits(int numberOfHits) ;
	
	public abstract int[][] getShipCoordinates() ;
	
	public abstract void setShipCoordinates(int [][] coordinates) ;
	
	
	
	
}
