package work_or.assignment.src.mianAPP;

public class PlayerGameGrid extends GameGrid {
    public PlayerGameGrid(int weight, int height, int shipNumber) {
        super(weight, height, shipNumber);
    }

    public void printGrid(){
        System.out.println("following is Player’s grid");
        for (String[] row : gameGrid) {
            for (String data : row) {
                System.out.printf("%s\t", data);
            }
            System.out.println();
        }


    }
}
