package work_or.assignment.src.mianAPP;

import java.util.Objects;

public class OpponentGameGrid extends GameGrid {
    public OpponentGameGrid(int weight, int height, int shipNumber) {
        super(weight, height, shipNumber);
    }


    public void printGrid(){
        System.out.println("“following is Opponent’s Grid");
        for (String[] row : gameGrid) {
            for (String data : row) {
                if(!Objects.equals(data, "*")){
                    System.out.printf("%s\t", data);
                }
                else{
                    System.out.printf("%s\t",".");
                }
            }
            System.out.println();
        }
        System.out.println();



    }

}
