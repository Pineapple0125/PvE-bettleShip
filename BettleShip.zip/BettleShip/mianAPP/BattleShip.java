package work_or.assignment.src.mianAPP;

import java.util.*;

public class BattleShip extends AbstractBattleShip{


    public BattleShip(String name) {
        this.name = name;

    }

    public String name;

    public int hits;

    public String shipOrientation = createOrientation();  // 船的朝向
    public int[][] shipCoordinates = new int[3][2]; // 船的坐标

//    public List<int[]> exist_ships = new ArrayList<int[]>();


    public final List<int []> destroyed_location = new ArrayList<int[]>();

    public final List<int []> miss_location = new ArrayList<int[]>();

    public void setShipBody(int X,int Y){

        if(Objects.equals(getShipOrientation(), "horizontal")){
            shipCoordinates[0][0] = X-1;
            shipCoordinates[0][1] = Y;

            shipCoordinates[2][0] = X+1;
            shipCoordinates[2][1] = Y;
        }
        else {
            shipCoordinates[0][0] = X;
            shipCoordinates[0][1] = Y-1;

            shipCoordinates[2][0] = X;
            shipCoordinates[2][1] = Y+1;
        }
//        exist_ships.add(shipCoordinates[0]);
//        exist_ships.add(shipCoordinates[1]);
//        exist_ships.add(shipCoordinates[2]);
    }

    private String createOrientation(){
        Random random = new Random();
        boolean i = random.nextBoolean();
        if (i){
//            setShipCoordinates(new int[3][1]);
            return "horizontal";  // 水平
        }
        else {
//            setShipCoordinates(new int[1][3]);
            return "vertical";  // 垂直
        }
    }

//    private void createCoordinates(int weight, int height){
//        if(Objects.equals(getShipOrientation(), "horizontal")&& weight>=3){
//            Random random = new Random();
//            X = random.nextInt(weight-2)+1;
//        }else if (Objects.equals(getShipOrientation(), "vertical") && height>=3){
//            Random random = new Random();
//            Y = random.nextInt(height-2)+1;
//        }
//        shipCoordinates[1][0] = X;
//        shipCoordinates[1][1] = Y;
//
//        setShipBody();
//    }

    @Override
    public boolean checkAttack(int row, int column) { // 这里填攻击坐标
//        System.out.println("here");

        for (int[] i :shipCoordinates) {
//            System.out.println(i);
            if(i[0] == row && i[1] == column && !destroyed_location.contains(i)){
//                System.out.println(exist_ships);
//                exist_ships.remove(i);
                destroyed_location.add(i);
                setHits(getHits()+1);
                return true;
            }else {
                miss_location.add(new int[]{row,column});

            }
        }
        return false;
    }

    public void setName(String name){this.name = name;}

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public int getHits() {
        return this.hits;
    }

    @Override
    public String getShipOrientation() {  //获取船的朝向
        return this.shipOrientation;
    }

    @Override
    public void setHits(int numberOfHits) { //设置船被击中
        this.hits = numberOfHits;
    }

    @Override
    public int[][] getShipCoordinates() { // 获取船的坐标
        return this.shipCoordinates;
    }

    @Override
    public void setShipCoordinates(int[][] coordinates) { // 设置船的坐标
        this.shipCoordinates = coordinates;
    }



}
