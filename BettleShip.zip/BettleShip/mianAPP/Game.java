package work_or.assignment.src.mianAPP;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;

import java.util.*;

public class Game implements GameControls{

    private int width;
    private int height;
    private int shiNumber;

    public PlayerGameGrid play;
    public OpponentGameGrid enemy;
    private final List<int[]> history = new ArrayList<>();

    private int shoot = 0;

    private int shoot_x = 0;
    private int shoot_y = 0;

    int[][] near;

    public Game(int weight, int height, int shiNumber) {
        this.width = weight;
        this.height = height;
        this.shiNumber = shiNumber;

        play = new PlayerGameGrid(this.width, this.height, this.shiNumber);
        enemy = new OpponentGameGrid(this.width, this.height, this.shiNumber);
    }

    @Override
    public void playRound(String input) {
        int X = Integer.parseInt(input.split(",")[0]);
        int Y = Integer.parseInt(input.split(",")[1]);
        if (Objects.equals(enemy.gameGrid[X][Y], "*")) {
            for (BattleShip i : (BattleShip[]) enemy.ships) {
                if (i.checkAttack(X, Y)) {
                    enemy.gameGrid[X][Y] = "X";
                    System.out.println("HIT " + i.name + "!!!");
                }
            }
        } else if (Objects.equals(enemy.gameGrid[X][Y], ".")) {
            enemy.gameGrid[X][Y] = "%";
        }
        enemy.printGrid();
    }
    public void RobotRound(){
        int r_x = 0;
        int r_y = 0;
        Random random = new Random();
        while (true){
            int number = 0; //用于计算是否重复
            if (shoot > 0){
                r_x = near[8-shoot][0];
                r_y = near[8-shoot][1];
                shoot-=1;
            }else {
                r_x = random.nextInt(width);
                r_y = random.nextInt(height);
            }
            if (history.size() != 0){
                for (int [] i :history) {
                    if (i[0] == r_x && i[1] == r_y){
                        number += 1;
                    }
                }
                if (number == 0 && r_y < height && r_y>=0 && r_x < width && r_x>=0) {
                    history.add(new int[]{r_x, r_y});
                    break;
                }

            }else {
                history.add(new int[]{r_x,r_y});
                break;
            }
        }

        if (Objects.equals(play.gameGrid[r_x][r_y], "*")){
            for (BattleShip i: (BattleShip[]) play.ships){
                if(i.checkAttack(r_x,r_y)){
                    shoot = 8;
                    shoot_x = r_x;
                    shoot_y = r_y;
                    near = new int[][]{
                            {shoot_x+1,shoot_y},
                            {shoot_x+2,shoot_y},
                            {shoot_x-1,shoot_y},
                            {shoot_x-2,shoot_y},
                            {shoot_x,shoot_y+1},
                            {shoot_x,shoot_y+2},
                            {shoot_x,shoot_y-1},
                            {shoot_x,shoot_y-2}};
                    play.gameGrid[r_x][r_y] = "X";
                    System.out.println("HIT "+i.name+"!!!");
                }
            }
        }else if (Objects.equals(play.gameGrid[r_x][r_y], ".")){
            play.gameGrid[r_x][r_y] = "%";
        }

        play.printGrid();


    }

    @Override
    public boolean checkVictory() {
        int play_exist = shiNumber;
        for (BattleShip i : (BattleShip[]) play.ships){
            if (i.hits == 3){
                play_exist--;
            }
        }
        if (play_exist == 0){
            System.out.println("You have lost!");

            Alert alert = new Alert(Alert.AlertType.INFORMATION);

            alert.setTitle("by 20213802045");
            alert.setHeaderText("You have lost!");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK){
                System.exit(0);
            }

            System.exit(0);
            return true;
        }

        int enemy_exist = shiNumber;
        for (BattleShip i : (BattleShip[])enemy.ships){
            if (i.hits == 3){
                enemy_exist--;
            }
        }
        if (enemy_exist == 0){
            System.out.println("You have won!");

            Alert alert = new Alert(Alert.AlertType.INFORMATION);

            alert.setTitle("by 20213802045");
            alert.setHeaderText("You have won!");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK){
                System.exit(0);
            }

            System.exit(0);
            return true;
        }

        return false;
    }

    @Override
    public void exitGame(String input) {
        System.out.println("Exiting game – thank you for playing");
        System.exit(0);
    }

    @Override
    public AbstractGameGrid getPlayersGrid() {
        return play;
    }

    @Override
    public AbstractGameGrid getOpponentssGrid() {
        return enemy;
    }
}
