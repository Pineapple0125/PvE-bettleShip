package work_or.assignment.src.mianAPP;

public abstract class AbstractGameGrid {
	
	public String [][] gameGrid;   // 游戏网格

	public AbstractBattleShip [] ships;  //战舰

	//populate the grid with "." characters
	public abstract void initializeGrid () ;

	//this should place the ship on the grid using "*" symbol  这应该将船放置在使用“*”符号的网格上
	public abstract void placeShip (AbstractBattleShip ship) ;
	
	//this should generate ships for both player and the opponent   这将为玩家和对手生成船只
	public abstract void generateShips (int numberOfShips) ;
	
}
