package work_or.assignment.src.mianAPP;


import javafx.scene.control.Label;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;


import java.util.Objects;

public class Apiece_enemy {

    public Label label;

    public String symbol;

    public Apiece_enemy(String symbol, int x , int y) {
        this.symbol = symbol;
        this.x = x;
        this.y = y;
//        ImageView imageView = null;
        if (Objects.equals(symbol, "*")){
            ImageView imageView = new ImageView("work_or/assignment/src/image/null_dark.png");
            label = new Label("", imageView);
            label.setOnMouseClicked(mouseEvent -> {
                MainGame.play_round(MouseClick());
                MainGame.vBox_enemy.getChildren().clear();
                MainGame.refresh_enemy();
                MainGame.checkVictory();
                MainGame.enemy_round();
            });
            label.setOnMouseEntered(mouseEvent -> {
                imageView.setImage(new Image("work_or/assignment/src/image/null_highlight.png"));
            });
            label.setOnMouseExited(mouseEvent -> {
                imageView.setImage(new Image("work_or/assignment/src/image/null_dark.png"));
            });
            imageView.setFitWidth(50);
            imageView.setFitHeight(50);
        }

        else if(Objects.equals(symbol, ".")){
            ImageView imageView = new ImageView("work_or/assignment/src/image/null_dark.png");
            label = new Label("", imageView);
            label.setOnMouseClicked(mouseEvent -> {
                MainGame.play_round(MouseClick());
                MainGame.vBox_enemy.getChildren().clear();
                MainGame.refresh_enemy();
                MainGame.checkVictory();
                MainGame.enemy_round();
            });
            label.setOnMouseEntered(mouseEvent -> {
                imageView.setImage(new Image("work_or/assignment/src/image/null_highlight.png"));
            });
            label.setOnMouseExited(mouseEvent -> {
                imageView.setImage(new Image("work_or/assignment/src/image/null_dark.png"));
            });
            imageView.setFitWidth(50);
            imageView.setFitHeight(50);
        }

        else if(Objects.equals(symbol, "%")){
            ImageView imageView = new ImageView("work_or/assignment/src/image/miss_dark.png");
            label = new Label("", imageView);
            label.setOnMouseClicked(mouseEvent -> {
                MainGame.play_round(MouseClick());
                MainGame.vBox_enemy.getChildren().clear();
                MainGame.refresh_enemy();
                MainGame.checkVictory();
                MainGame.enemy_round();
            });
            label.setOnMouseEntered(mouseEvent -> {
                imageView.setImage(new Image("work_or/assignment/src/image/miss_highlight.png"));
            });
            label.setOnMouseExited(mouseEvent -> {
                imageView.setImage(new Image("work_or/assignment/src/image/miss_dark.png"));
            });
            imageView.setFitWidth(50);
            imageView.setFitHeight(50);
        }

        else if (Objects.equals(symbol, "X")) {
            ImageView imageView = new ImageView("work_or/assignment/src/image/death_dark.png");
            label = new Label("", imageView);
            label.setOnMouseClicked(mouseEvent -> {
                MainGame.play_round(MouseClick());
                MainGame.vBox_enemy.getChildren().clear();
                MainGame.refresh_enemy();
                MainGame.checkVictory();
                MainGame.enemy_round();
            });
            label.setOnMouseEntered(mouseEvent -> {
                imageView.setImage(new Image("work_or/assignment/src/image/death_highlight.png"));
            });
            label.setOnMouseExited(mouseEvent -> {
                imageView.setImage(new Image("work_or/assignment/src/image/death_dark.png"));
            });
            imageView.setFitWidth(50);
            imageView.setFitHeight(50);
        }



    }

    public String MouseClick(){
        return x +","+ y;
    }


    private int x;
    private int y;

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    //    private int [][]position;
    private boolean exist = true;

    public boolean getExist() {
        return exist;
    }

    public void setExist() {
        this.exist = false;
    }


}
