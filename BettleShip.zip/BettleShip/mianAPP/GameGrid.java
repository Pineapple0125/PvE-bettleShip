package work_or.assignment.src.mianAPP;

import java.util.Objects;
import java.util.Random;

public class GameGrid extends AbstractGameGrid{

    private int weight;
    private int height;

//    private BattleShip [] Ships;

    public GameGrid(int weight, int height, int shipNumber){
        this.weight = weight;
        this.height = height;


        ships = new BattleShip[shipNumber];
//        ships = (BattleShip[])ships;
//        Ships = (BattleShip[]) ships ;//向下转型 但现在没必要

        initializeGrid();

        generateShips(shipNumber);
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    @Override
    public void initializeGrid() {
        gameGrid = new String[weight][height];

        for (int i = 0; i < weight; i++) {
            for (int j = 0; j < height; j++) {
                gameGrid[i][j] = ".";
            }
        }
    }

    @Override
    public void placeShip(AbstractBattleShip ship) {

        BattleShip Ship = (BattleShip) ship;
        int X = 1;
        int Y = 1;
        if(Objects.equals(Ship.shipOrientation, "horizontal")&& weight>=3){
            Random random = new Random();
            X = random.nextInt(weight-2)+1;
            Y = random.nextInt(height);
        }else if (Objects.equals(Ship.shipOrientation, "vertical") && height>=3){
            Random random = new Random();
            X = random.nextInt(weight);
            Y = random.nextInt(height-2)+1;
        }
        Ship.shipCoordinates[1][0] = X;
        Ship.shipCoordinates[1][1] = Y;

        if(Objects.equals(Ship.shipOrientation, "vertical")){

            Ship.shipCoordinates[0][0] = X;
            Ship.shipCoordinates[0][1] = Y-1;

            Ship.shipCoordinates[2][0] = X;
            Ship.shipCoordinates[2][1] = Y+1;
        }
        else {
            Ship.shipCoordinates[0][0] = X-1;
            Ship.shipCoordinates[0][1] = Y;

            Ship.shipCoordinates[2][0] = X+1;
            Ship.shipCoordinates[2][1] = Y;

        }

        for (int []i :Ship.shipCoordinates) {
            gameGrid[i[0]][i[1]] = "*";

        }

    }

    @Override
    public void generateShips(int numberOfShips) {
        for (int i = 1; i < numberOfShips+1; i++) {
            BattleShip ship = new BattleShip("Ship "+i);


            placeShip(ship);

            // 装填
            ships[i-1] =  ship;
            ships[i-1].name = ship.name;
            ships[i-1].shipCoordinates = ship.shipCoordinates;
            ships[i-1].shipOrientation = ship.shipOrientation;
            ships[i-1].hits = ship.hits;

        }

    }
}
